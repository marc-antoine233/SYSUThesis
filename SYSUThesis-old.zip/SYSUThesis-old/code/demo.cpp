#include <iostream>
int main()
{
    ::std::cout << "hello world" << ::std::endl;
    return 0;
}